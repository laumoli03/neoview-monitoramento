
# NeoView - Monitoramento de Glicose

Este projeto foi criado para exibir leituras de glicose em tempo real com ESP32, tiras G-Tech e um sistema de visualização simples em HTML.

### 🌐 Acesse online pelo GitHub Pages

Assim que ativar no GitHub Pages, o app estará disponível no link:
`https://<seu-usuario>.github.io/neoview-monitoramento/`

---

Criado com ❤ por Laura e ChatGPT ✨
